package iss.java.mail;


import java.io.IOException;

import java.util.List;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class JimmyMail2014302580324 implements IMailService
{
    private String text = null;
	private String serverSmtp = "smtp.sina.com.cn";
	private String serverImap = "imap.sina.com.cn";
    private final  Properties prop = System.getProperties();
    private  User user =  new User("skyfirst11@sina.com", "lllllll1");
    private  Session session;
    
	@Override
	public void connect() throws MessagingException 
	{
		// TODO Auto-generated method stub
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.host", serverSmtp);
		prop.put("mail.transport.protocol", "smtp");
		prop.put("mail.imap.host",serverImap);
        prop.put("mail.store.protocol","imap");
		session = Session.getInstance(prop, user);
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException 
	{
		// TODO Auto-generated method stub
		final MimeMessage message = new MimeMessage(session);
	    message.setFrom(new InternetAddress(user.getUsername()));
	    message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
	    message.setSubject(subject);
	    message.setContent(content.toString(), "text/html;charset=utf-8");
	    message.saveChanges();
	    Transport transport = session.getTransport();
	    transport.connect();
		transport.sendMessage(message, message.getAllRecipients());
		transport.close();
	}

	@Override
	public boolean listen() throws MessagingException
	{
		// TODO Auto-generated method stub
		Store store = session.getStore();
	    store.connect();

	    Folder folder = store.getFolder("inbox");
	    folder.open(Folder.READ_ONLY);

	    int messageCount = folder.getNewMessageCount();
		System.out.println("newMessage��"+messageCount);
		folder.close(false);
		store.close();
		if(messageCount >= 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException 
	{
		// TODO Auto-generated method stub
		Store store = session.getStore();
		store.connect();
		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		Message[] messages = folder.getMessages();
		
		int count = messages.length-1;
		
			for(int i = 0;i<=count;i++){
			sender = (messages[i].getFrom()[0]).toString();
			subject = messages[i].getSubject();
			System.out.println( "�����˵�ַ��"+ i + sender+"\n");
			System.out.println("���ʼ�����"+ i + subject+"\n");
			text += messages[i].getContent().toString();
			}
		
		
		folder.close(false);
		store.close();
		return text;
	}
	
	
	 public void send(List<String> recipients, String subject, Object content) throws AddressException, MessagingException 
	 {
	      // ����mime�����ʼ�
	      final MimeMessage message = new MimeMessage(session);
	      // ���÷�����
	      message.setFrom(new InternetAddress(user.getUsername()));
	      // �����ռ�����
	      final int num = recipients.size();
	      InternetAddress[] addresses = new InternetAddress[num];
	      for (int i = 0; i < num; i++) 
	      {
	          addresses[i] = new InternetAddress(recipients.get(i));
	      }
	      message.setRecipients(RecipientType.TO, addresses);
	      // ��������
	      message.setSubject(subject);
	      // �����ʼ�����
	      message.setContent(content.toString(), "text/html;charset=utf-8");
	      // ����
	      Transport.send(message);
	  }
}
